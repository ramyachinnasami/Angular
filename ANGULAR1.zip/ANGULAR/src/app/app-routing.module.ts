import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './components/auth/auth.component';
import { LoginComponent } from 'app-components/auth/login/login.component';
import { ForgotPasswordComponent } from 'app-components/auth/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from 'app-components/auth/change-password/change-password.component';



const routes: Routes = [
	{
		path: 'user',
		component: AuthComponent,
		children: [
			{
				path: 'login',
				component: LoginComponent
			},
			{
				path: 'forgotpassword',
				component: ForgotPasswordComponent
			},
			{
				path: 'changepassword',
				component: ChangePasswordComponent
			},
		],
	},
	{
		path: '**',
		redirectTo: '404',
		pathMatch: 'full'
	}
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes)
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
