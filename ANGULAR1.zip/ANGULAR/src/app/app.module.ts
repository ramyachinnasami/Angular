import { BrowserModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AuthenticationModule } from './core/auth/authentication.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { CoreModule } from './core/core.module';
import { LayoutConfigService } from './core/services/layout-config.service';
import { MenuConfigService } from './core/services/menu-config.service';
import { PageConfigService } from './core/services/page-config.service';
import { UtilsService } from './core/services/utils.service';
import { ClassInitService } from './core/services/class-init.service';
import { NgbModule, NgbRatingModule, NgbTimepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GestureConfig, MatProgressSpinnerModule } from '@angular/material';
import { OverlayModule } from '@angular/cdk/overlay';
import { PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG, PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { LayoutConfigStorageService } from './core/services/layout-config-storage.service';
import { SubheaderService } from './core/services/layout/subheader.service';
import { HeaderService } from './core/services/layout/header.service';
import { MenuAsideService } from './core/services/layout/menu-aside.service';
import { LayoutRefService } from './core/services/layout/layout-ref.service';
import { SplashScreenService } from './core/services/splash-screen.service';
import 'hammerjs';
// Auth and DefaultComponetnts
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './core/services/material';
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { HttpService } from 'http-service';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { DynamicroutesService  } from './core/services/dynamicroutes.service';
import { RouteLoaderService } from 'core/services/route-loader.service';
import { NgSelectModule } from '@ng-select/ng-select';
import {DragDropModule} from '@angular/cdk/drag-drop';

import { NgBootstrapFormValidationModule } from 'ng-bootstrap-form-validation';
import { ChartsModule } from 'ng2-charts';




const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
	// suppressScrollX: true
};

@NgModule({
	declarations: appComponents,
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		AppRoutingModule,
		HttpClientModule,
		CoreModule,
		OverlayModule,
		AuthenticationModule,
		NgxPermissionsModule.forRoot(),
		NgbModule.forRoot(),
		TranslateModule.forRoot(),
		MatProgressSpinnerModule,
		NgbRatingModule,
		NgbTimepickerModule,
		// for login
		FormsModule,
		MaterialModule,
		ReactiveFormsModule,
		// for layout module
		LoadingBarModule.forRoot(),
		AngularDualListBoxModule,
		NgSelectModule,
		DragDropModule,
		NgBootstrapFormValidationModule.forRoot(),
		NgBootstrapFormValidationModule,
		PerfectScrollbarModule,
		ChartsModule
	],
	providers: [
		LayoutConfigService,
		LayoutConfigStorageService,
		LayoutRefService,
		MenuConfigService,
		PageConfigService,
		UtilsService,
		ClassInitService,
		SplashScreenService,
		{
			provide: PERFECT_SCROLLBAR_CONFIG,
			useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
		},

		// template services
		SubheaderService,
		HeaderService,
		MenuAsideService,
		{
			provide: HAMMER_GESTURE_CONFIG,
			useClass: GestureConfig
		},
		HttpService,
		{ provide: 'Components', useValue : validateRoutes },
		DynamicroutesService,
		RouteLoaderService,

	],
	bootstrap: [appComponents[0]],
	entryComponents: entryComponents
})
export class AppModule {
}
