import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, HostBinding, OnInit, ViewChild, NgZone } from '@angular/core';
import { LayoutConfigService } from 'core/services/layout-config.service';
import { ClassInitService } from 'core/services/class-init.service';
import * as objectPath from 'object-path';
import { DomSanitizer } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { PageConfigService } from 'core/services/page-config.service';
import { filter } from 'rxjs/operators';
import { SplashScreenService } from 'core/services/splash-screen.service';
import { Subscription } from 'rxjs';
import { TokenStorage } from 'core/auth/token-storage.service';
import { MenuConfig } from 'app-config/menu';
import { DynamicroutesService } from 'core/services/dynamicroutes.service';
import { MenuConfigService } from 'core/services/menu-config.service';
import { RouteLoaderService } from 'core/services/route-loader.service';
import { RoutesMenu } from 'app-interface/routesmenu';
import { HttpService } from 'core/services/http.service';
import { RouteEvent } from 'app-interface/routeevent';
import { ActivatedRoute } from '@angular/router';

// LIST KNOWN ISSUES
// [Violation] Added non-passive event listener; https://github.com/angular/angular/issues/8866

@Component({
	// tslint:disable-next-line:component-selector
	selector: 'body[m-root]',
	templateUrl: './app.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements AfterViewInit, OnInit {
	title = 'Screener App';

	@HostBinding('style') style: any;
	@HostBinding('class') classes: any = '';

	@ViewChild('splashScreen', { read: ElementRef })
	splashScreen: ElementRef;
	splashScreenImage: string;
	protected subscription: Subscription;
	private menuConfig: MenuConfig = new MenuConfig();
	configLoaded = true;

	constructor(
		private layoutConfigService: LayoutConfigService,
		private classInitService: ClassInitService,
		private sanitizer: DomSanitizer,
		private router: Router,
		private pageConfigService: PageConfigService,
		private splashScreenService: SplashScreenService,
		private token: TokenStorage,
		private dynamicRoutes: DynamicroutesService,
		private menuConfigService: MenuConfigService,
		private changeLoader: RouteLoaderService,
		private http: HttpService,
		private ngzone: NgZone,
		private activeRoute: ActivatedRoute,
	) {
		// This one calls if the user refresh the page.
		this.token.getAccessToken().subscribe(data => {
			if (data) {
				// Construct Routes based on routes
				this.http.get<RoutesMenu>('/root').subscribe(result => {
					if (result) {
						// Constrct Routes
						this.dynamicRoutes.constructRoutes(result.routes);
						// Construct Left menu
						this.menuConfig.setLeftMenu(result.menu);
						this.menuConfigService.setModel(this.menuConfig);
						this.changeLoader.value = true;
						const queryParams = this.activeRoute.snapshot.queryParams['redirectiardata'];
						if (!queryParams) {
							// Redirect last updated location when the user refresh the page.
							this.token.getRecentURL().subscribe(recentInfo => {
								const redirectURL = recentInfo.url;
								delete recentInfo.url;
								this.ngzone.run(() => this.router.navigate([redirectURL]));
							});
						}
					} else {
						this.changeLoader.value = true;
					}
				});

			} else {
				this.changeLoader.value = true;
			}
		});

		// register translations
		// override config by router change from pages config
		this.router.events
			.pipe(filter(event => event instanceof NavigationEnd))
			.subscribe(event => {
				/** Save current path and component name in recent url storage */
				const routeEvent = <RouteEvent>event;
				const getFirstName = routeEvent.url.split('/');
				this.router.config[0].children.filter(data => {
					// Filter current url with existing child component instead of dynamic id URL's
					if (data.path === getFirstName[1]) {
						const generatePath = {
							path: data.path,
							url: routeEvent.url
						};
						this.token.setRecentURL(generatePath);
						return true;
					}
				});

				// this.layoutConfigService.setModel({ page: objectPath.rereget(this.pageConfigService.getCurrentPageConfig(), 'config') }, true);
			});

		// metronic style setup
		// subscribe to class update event
		this.classInitService.onClassesUpdated$.subscribe(classes => {
			// get body class array, join as string classes and pass to host binding class
			setTimeout(() => this.classes = classes.body.join(' '));
		});

		this.layoutConfigService.onLayoutConfigUpdated$.subscribe(model => {
			this.classInitService.setConfig(model);

			this.style = '';
			if (objectPath.get(model.config, 'self.layout') === 'boxed') {
				const backgroundImage = objectPath.get(model.config, 'self.background');
				if (backgroundImage) {
					this.style = this.sanitizer.bypassSecurityTrustStyle('background-image: url(' + objectPath.get(model.config, 'self.background') + ')');
				}
			}

			// splash screen image
			this.splashScreenImage = objectPath.get(model.config, 'loader.image');
		});
	}
	ngOnInit(): void {
		// Checking token in localstorag
		this.subscription =
			this.router.events.subscribe((event) => {
				if (event instanceof NavigationEnd) {
					this.token.getAccessToken().subscribe(data => {
						// add the URL which should load without login
						const directurls = [
							'/user/forgotpassword',
							'/user/changepassword',
							'/emaildirectlink'
						];
						// getting the url without the query string
						const currenturl = this.router.url.split('?')[0];
						// restricting redirection to the login page
						if (directurls.includes(currenturl)) {
							return 0;
						}
						// checking login status and redarecting to the dashbord or loginpage.
						if (!data) {
							this.router.navigate(['/user/login']);
						} else if (this.router.url === '/user/login') {
							this.router.navigate(['/']);
						}
					});
				}
			});
	}
	ngAfterViewInit(): void {
		if (this.splashScreen) {
			this.splashScreenService.init(this.splashScreen.nativeElement);
		}
	}
}
