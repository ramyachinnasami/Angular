/** candidate retrieve response */
export interface ICandidateInfo {
    candidateInfo: any;
    candidateId: string;
    candidateFirstName: string;
    candidateEmailId: string;
    candidateMobileNo: string;
    candidateSource: number;
    candidateType: string;
    categoryId: string;
    workExpYears: any;
    workExpMonths: string;
    currentSalLakhs: string;
    officialNoticePeriod: any;
    negotiableNoticePeriod: any;
    resume: any;
    alternateMobileNo: any;
    sourceId: any;
    candidateLastName: any;
    candidateDOB: any;
    expectSalLakhs: any;
    expectSalThousands: any;
    currentSalThousands: any;
    resourceType: any;
    customerId: any;
    // tslint:disable-next-line:no-trailing-whitespace
    
}
