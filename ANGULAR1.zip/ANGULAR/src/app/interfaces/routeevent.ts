/** Get url from router event in app component */
export interface RouteEvent {
	url: string;
}
