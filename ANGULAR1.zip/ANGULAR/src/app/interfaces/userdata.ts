/** user details response after login */
export interface UserData {
    emailId: string;
    name: string;
    userId: string;
    image: string;
}
