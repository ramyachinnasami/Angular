/** user response for login */
export interface Login {
    token: string;
    emailId: string;
    name: string;
    userId: string;
    indexComponent: any;
}
