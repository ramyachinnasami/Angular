export interface RoutesMenu {
    menu: any;
    routes: any;
}
