import {
	Component,
	OnInit,
	ChangeDetectorRef
} from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { SpinnerButtonOptions } from '../../partials/spinner-button/button-options.interface';
import { HttpService } from 'core/services/http.service';

@Component({
	selector: 'm-forgot-password',
	templateUrl: './forgot-password.component.html',
	styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
	private model: any = { email: '' };
	public loading = false;
	public displaymessage: string = 'Forgotten Password ?';
	// on action complition to hide the form.
	public reset: number = 0;

	errors: any = [];

	/** For form validation */
	email = new FormControl('', [Validators.required, Validators.email]);

	spinner: SpinnerButtonOptions = {
		active: false,
		spinnerSize: 18,
		raised: true,
		buttonColor: 'warn',
		spinnerColor: 'accent',
		fullWidth: false
	};

	constructor(
		public http: HttpService,
		private changedetector: ChangeDetectorRef
	) { }

	ngOnInit(): void { }

	/**
	 * Submits forgot password component
	 */
	protected submit(): void {
		// Check inputs is  valid
		if (this.email.valid) {
			// Enable perloader in submit button
			this.spinner.active = true;
			this.forgot(this.model);
		} else {
			// Show error message when we click the submit button
			this.email.markAsTouched();
		}
	}
	/**
	 * forgot password actions
	 * @param model email id to reset the password
	 */
	private forgot(model: any): void {
		this.http.post('/forgotpassword', model).subscribe((res) => {
			if (res) {
				// changing message after mail sent
				this.displaymessage = 'The Password has been sent to your mail ID.';
				this.reset = 1;
			}
			// Reset submit button animation
			this.spinner.active = false;
			this.changedetector.detectChanges();
		});

	}


}
