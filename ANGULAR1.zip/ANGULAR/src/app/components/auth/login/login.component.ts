import {
	Component,
	OnInit,
	Input,
	OnDestroy,
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	HostBinding
} from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { SpinnerButtonOptions } from '../../partials/spinner-button/button-options.interface';
import { TokenStorage } from 'core/auth/token-storage.service';
import { Login } from 'app-interface/login';
import { HttpService } from 'http-service';
import { DynamicroutesService } from 'core/services/dynamicroutes.service';
import { MenuConfigService } from 'core/services/menu-config.service';
import { MenuConfig } from 'app-config/menu';
import { RoutesMenu } from 'app-interface/routesmenu';

@Component({
	selector: 'm-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit, OnDestroy {
	public model: any = { emailId: '', password: '' };
	@HostBinding('class') classes: string = 'm-login__signin';

	@Input() action: string;

	errors: any = [];
	public menuConfig: MenuConfig = new MenuConfig();
	/** Showing submit button in login */
	spinner: SpinnerButtonOptions = {
		active: false,
		spinnerSize: 18,
		raised: true,
		buttonColor: 'warn',
		spinnerColor: 'accent',
		fullWidth: false
	};

	/** For form validation */
	email = new FormControl('', [Validators.required, Validators.email]);
	password = new FormControl('', [Validators.required]);

	constructor(
		private router: Router,
		private http: HttpService,
		private token: TokenStorage,
		private changedetector: ChangeDetectorRef,
		private dynRoutes: DynamicroutesService,
		private menuConfigService: MenuConfigService,
	) { }

	ngOnInit(): void {

	}

	/** Form Submission Process */
	public submit(): void {
		// Check all inputs are valid
		if (this.email.valid && this.password.valid) {
			// Enable perloader in submit button
			this.spinner.active = true;
			this.login(this.model);
		} else {
			// Show error message when we click the submit button
			this.email.markAsTouched();
			this.password.markAsTouched();
		}
	}

	/**
	 * Login operations
	 * @param logindetails the username and password for login
	 */
	private login(logindetails: any): void {
		this.http.post<Login>('/login', logindetails).subscribe((res) => {
			if (res) {
				// Set access Token for authorization
				this.token.setAccessToken(res.token);
				// Set recent redirect data for defalut redirection
				this.token.setRecentURL(res.indexComponent);

				const redirectPath = res.indexComponent.url;
				delete res.token;
				delete res.indexComponent;

				// Set User information for showing header
				this.token.setUserData(res);
				this.http.get<RoutesMenu>('/root').subscribe((result) => {
					// Constrct Routes
					this.dynRoutes.constructRoutes(result.routes);
					// Construct Left menu
					this.menuConfig.setLeftMenu(result.menu);
					this.menuConfigService.setModel(this.menuConfig);
					this.router.navigate([redirectPath]);
				});
			} else {
				this.model.password = '';
				this.password.markAsPristine();
				this.password.markAsUntouched();
				this.changedetector.detectChanges();

			}
			// Reset submit button animation
			this.spinner.active = false;
			this.changedetector.detectChanges();
		});
	}

	ngOnDestroy(): void {
	}
}
