import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { SpinnerButtonOptions } from 'app-components/partials/spinner-button/button-options.interface';
import { NgForm, FormControl, Validators, FormGroup } from '@angular/forms';
import { HttpService } from 'core/services/http.service';
import { Router } from '@angular/router';
import { MatDialogRef } from '@angular/material';

@Component({
	selector: 'm-change-password',
	templateUrl: './change-password.component.html',
	styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

	/** For form validation */
	changePassword = new FormGroup({
		newPassword: new FormControl('', [Validators.required, (control: FormControl) => {
			if (control.value) {
				// validation for No Of Positions
				const value = control.value;
				const cnfpassword = this.changePassword.value.conformPassword;
				if (cnfpassword && value !== cnfpassword) {
					return {notsame: true};
				}
			}
			return null;
		  }]),
		conformPassword: new FormControl('', [Validators.required, (control: FormControl) => {
			if (control.value) {
				// validation for No Of Positions
				const value = control.value;
				const newpassword = this.changePassword.value.newPassword;
				if (newpassword && value !== newpassword) {
					return {notsame: true};
				}
			}
			return null;
		  }]),
	});

	constructor(private dialogRef: MatDialogRef<ChangePasswordComponent>,
		private http: HttpService,
		private router: Router,
		private changedetector: ChangeDetectorRef
	) { }

	ngOnInit(): void {
	}

  	/** Close the Popup **/
  	public onNoClick(): void {
    	this.dialogRef.close();
	}

	/**
	 * change password action
	 * @param model data to change password
	 */
	public submitChangePassword(): void {
		if (this.changePassword.valid) {
			const myformData = this.changePassword.getRawValue();
			this.http.post('/changepassword', myformData, {success: true}).subscribe((res) => {
				if (res) {
					this.onNoClick();
				}
			});
		}
	}

}
