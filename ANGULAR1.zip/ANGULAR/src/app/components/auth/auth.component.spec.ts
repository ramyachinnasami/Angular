import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthComponent } from './auth.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LayoutConfigService } from 'core/services/layout-config.service';
import { RouterTestingModule } from '@angular/router/testing';
import { UtilsService } from 'core/services/utils.service';
import { LayoutConfigStorageService } from 'core/services/layout-config-storage.service';
import { MatSelectModule, MatInputModule } from '@angular/material';

describe('AuthComponent', () => {
  let component: AuthComponent;
  let fixture: ComponentFixture<AuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, MatSelectModule, MatInputModule],
      declarations: [ AuthComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [LayoutConfigService, UtilsService, LayoutConfigStorageService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  /* it('should create', () => {
    expect(component).toBeTruthy();
  }); */
});
