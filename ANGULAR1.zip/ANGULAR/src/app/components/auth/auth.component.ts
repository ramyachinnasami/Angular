import {
	Component,
	OnInit,
	Input,
	HostBinding,
	OnDestroy
} from '@angular/core';

@Component({
	selector: 'm-auth',
	templateUrl: './auth.component.html',
	styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit, OnDestroy {
	// @HostBinding('id') id = 'm_login';
	@HostBinding('class')
	// tslint:disable-next-line:max-line-length
	classses: any = 'm-grid m-grid--hor m-grid--root m-page';

	@Input() action = '';
	today: number = Date.now();

	constructor() { }

	ngOnInit(): void {
	}

	ngOnDestroy(): void {

	}

}
