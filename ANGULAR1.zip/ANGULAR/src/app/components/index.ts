import { AppComponent } from '../app.component';
import { AuthComponent } from './auth/auth.component';
import { LoginComponent } from './auth/login/login.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';

export const appComponents = [
    AppComponent,
    AuthComponent,
    LoginComponent,
    ForgotPasswordComponent,
];
