import { TestBed } from '@angular/core/testing';

import { DynamicroutesService } from './dynamicroutes.service';

describe('DynamicroutesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  /* it('should be created', () => {
    const service: DynamicroutesService = TestBed.get(DynamicroutesService);
    expect(service).toBeTruthy();
  }); */
});
