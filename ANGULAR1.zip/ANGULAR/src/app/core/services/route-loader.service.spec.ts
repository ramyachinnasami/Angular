import { TestBed } from '@angular/core/testing';

import { RouteLoaderService } from './route-loader.service';

describe('RouteLoaderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

/*   it('should be created', () => {
    const service: RouteLoaderService = TestBed.get(RouteLoaderService);
    expect(service).toBeTruthy();
  }); */
});
