import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {
  public id: any;
  public commonData: any = {};

  constructor() { }


  /**
   * Set the id to use in other component
   */
  public set candidateid(data: any) {
    this.id = data;
  }

  /**
   * get the id to use in other component
   */
  public get candidateid() {
    return this.id;
  }

  /**
   * Clears id data
   */
  public clearcandidateid(): void {
    this.id = ``;
  }

  /**
   * Set the data by key
   */
  public setData(key, value): void {
    this.commonData[key] = value;
  }

  /**
   * Get the data by Key
   */
  public getData(key): void {
    return this.commonData[key] ? this.commonData[key] : null;
  }

}
