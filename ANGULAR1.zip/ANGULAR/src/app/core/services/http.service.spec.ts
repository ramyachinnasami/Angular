import { TestBed, inject } from '@angular/core/testing';
import { HttpService } from './http.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { TokenStorage } from '../auth/token-storage.service';
import { UtilsService } from './utils.service';
import { MatSelectModule, MatInputModule } from '@angular/material';

describe('HttpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, MatSelectModule, MatInputModule],
      providers: [HttpService, HttpClient, TokenStorage, UtilsService]
    });
  });

  /* it('should be created', inject([HttpService], (service: HttpService) => {
    expect(service).toBeTruthy();
  })); */
});
