import { Injectable, HostListener } from '@angular/core';
import { MatDialog } from '@angular/material';


@Injectable({
  providedIn: 'root'
})
export class PopupsService {

  constructor(public dialog: MatDialog,
  ) { }
  public dialogRef;
  public _popupdata;

  /**
   * Opens dialog
   * @param component the componet name which should be poped up.
   * @param [type] type of the popup
   * @param [data] to get from child component (popup component)
   * @param [width] set width of the popup
   * @returns dialog
   */

  public openDialog(component: any, type?: string, data?: any, width?: string): any {
    let popupsize = (window.innerWidth < 500 ) ? '100%': '60%';
    const size = (width === undefined) ? popupsize : `${width}%`;
    this.dialogRef = this.dialog.open(component, {
      // for full size popus
      maxWidth: '100vw',
      maxHeight: '100vh',
      // normal setting
      width: size,
      disableClose: true,
      panelClass: 'custom-dialog-container',
      data: { values: data, type: (type === undefined) ? `popup` : `${type}` }
    });
  }

  /**
   * opens deletep popup
   * @param component the componet name which should be poped up.
   * @param data to get from child component (popup component)
   * @param [width] set width of the popup
   */

  public openDeleteDialog(component: any, data: any, width?: string) {
    let popupsize = (window.innerWidth < 500 ) ? '100%': '60%';
    const size = (width === undefined) ? popupsize : width;
    this.dialogRef = this.dialog.open(component, {
      // GIVE OPTIONAL PARAMETER WIDTH TO SET THE SIZE OF POPUP
      width: size,
      panelClass: 'custom-dialog-container',
      data: { values: data, type: `delete` }
    });

  }
  public openCommonDialog(component: any, type?: string, data?: any, width?: string) {
    let popupsize = (window.innerWidth < 500 ) ? '100%': '60%';
    const size = (width === undefined) ? popupsize : width;
    this.dialogRef = this.dialog.open(component, {
      // GIVE OPTIONAL PARAMETER WIDTH TO SET THE SIZE OF POPUP
      width: size,
      panelClass: 'custom-dialog-container',
      data: { values: data, type: `common` }
    });

  }

  /**
   * Set the popupdata to use in other component
   */
  public set popupData(data: any) {
    this._popupdata = data;
  }

  /**
   * Set the popupdata to use in other component
   */
  public get popupData() {
    return this._popupdata;
  }

  /**
   * Clears popup data
   */
  public clearPopupData(): void {
    this._popupdata = ``;
  }

}
