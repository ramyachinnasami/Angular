import { Injectable, Inject } from '@angular/core';
import { Router} from '@angular/router';

@Injectable()
export class DynamicroutesService {

  constructor(@Inject('Components') public dymComponents: any, private router: Router) { }

  /* Push server side response components into pagecomponent children */
  public constructRoutes(routes: any) {
    this.router.config.forEach((result, i) => {

			if (result.component !== undefined && result.path === '') {
        this.router.config[i].children = this.buildRoutes(routes);
			}
    });
    this.router.resetConfig( this.router.config );
  }
  /* Convert string component to actual component */
  private buildRoutes(routes: any) {
    routes.forEach((data, i) => {
     if (data.path !== '') {
        routes[i].component = this.dymComponents[data.component];
      }
    });
    return routes;
  }


}
