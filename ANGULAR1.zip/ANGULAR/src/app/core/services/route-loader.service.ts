import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class RouteLoaderService {
  /* For showing preloader while constructing dynamic routes */
  public changeLoader$: BehaviorSubject<any> = new BehaviorSubject<boolean>(false);

  public set value(value: boolean) {
    this.changeLoader$.next(value);
  }

}
