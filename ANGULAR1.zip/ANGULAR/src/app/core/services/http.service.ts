import { environment } from '../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { NotificationService } from './notification.service';
import { Notify } from '../models/notify';
import { TokenStorage } from '../auth/token-storage.service';
import { HttpNotify } from '../models/httpnotify';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

const serverURL = environment.baseURL;

@Injectable()
export class HttpService {

  private notifyObj: Notify;

  constructor(
      private http: HttpClient,
      public notifyService: NotificationService,
      private tokenStorage: TokenStorage,
      private router: Router,
      private dialogRef: MatDialog
    ) { }

  /**
   * GET request to server
   * @param URL Requested URL
   * @param params URL parameters (optional)
   * @param notify For showing success/failure notifications
   * @returns {Observable<any>} Validated data
   */
  public get<T>(URL: string, params?: any, notify?: HttpNotify | null): Observable<T> {
    return this.http.get<T>(
      serverURL + URL,
      {
        headers : this.generateHeaders(),
        withCredentials: true,
        params: params
      }
    ).pipe(
      tap(datas => notify ? this.showNotify(notify, datas) : ''),
      map((datas: T) => this.validateResponse(<T>datas)),
      catchError(this.httpError<any>('Get Request', notify))
    );
  }

  /**
   * POST request to server
   * @param URL Requested URL
   * @param params URL parameters (optional)
   * @param notify For showing success/failure notifications
   * @returns {Observable<any>} Validated data
   */
  public post<T>(URL: string, params?: any | {}, notify?: HttpNotify | null): Observable<T> {
    return this.http.post<T>(
      serverURL + URL,
      params,
      {
        headers : this.generateHeaders(),
        withCredentials: true
      }
    ).pipe(
      tap(datas => this.showNotify(notify, datas)),
      map((datas: T) => this.validateResponse(<T>datas)),
      catchError(this.httpError<any>('Post Request', notify))
    );
  }

  /**
   * PUT request for update datas from server
   * @param URL Requested URL
   * @param params URL parameters (mandatory)
   * @param notify For showing success/failure notifications
   * @returns {Observable<any>} Validated data
   */
  public update<T>(URL: string, params: any, notify?: HttpNotify | null): Observable<T> {
    return this.http.put<T>(
      serverURL + URL,
      params,
      { headers : this.generateHeaders(), withCredentials: true, }
    ).pipe(
      tap(datas => notify ? this.showNotify(notify, datas) : ''),
      map((datas: T) => this.validateResponse(<T>datas)),
      catchError(this.httpError<any>('Update Request', notify))
    );
  }

  /**
   * DELETE request to remove datas from server
   * @param URL Requested URL
   * @param params URL parameters (mandatory)
   * @param notify For showing success/failure notifications
   * @returns {Observable<any>} Validated data
   */
  public delete<T>(URL: string, params: any, notify?: HttpNotify | null): Observable<T> {
    return this.http.delete<T>(
      serverURL + URL,
      {
        headers : this.generateHeaders(),
        withCredentials: true,
        params: params
      }
    ).pipe(
      tap(datas => notify ? this.showNotify(notify, datas) : ''),
      map((datas: T) => this.validateResponse(<T>datas)),
      catchError(this.httpError<any>('Delete Request', notify))
    );
  }

  /**
   * Capture server/request error
   * @param operation For checking incoming error data
   * @param notify For showing success/failure notifications
   * @param result return results based on any class/interface
   * @returns {any} client/server side error message
   */
  private httpError<T> (operation = '', notify: HttpNotify | null, result?: T): any {
    return (data: any): Observable<T> => {
      // handling session expired, when token has expired, redarect to login
      // if (data.error.code === 'Unauthorized' || data.error.code === 'InvalidCredentials') //alternative
      if ( data.status === 401 ) {
        this.tokenStorage.clear();
        // for closing all the open popup before loging out
        this.dialogRef.closeAll();
        this.router.navigate(['/login']);
      }

      // Showing server side error msg
      if (data.error.message) {
        data.message = data.error.message;
      }

      // this.showNotify(notify, data);
      return of(result as T);
    };
  }

  /**
   * To construct and send headers with all requests
   * @returns {HttpHeaders} valid Http header
   */
  private generateHeaders(): any {

    const headerOptions = {
      'Accept': 'application/json'
    };

    /* Add authorization header for validating token from server side */
    this.tokenStorage.getAccessToken().subscribe(data => {
			if (!data) {
        headerOptions['Authorization'] = 'Bearer ' + data;
      }
		});

    return new HttpHeaders(headerOptions);
  }

  /**
   * To avoid proceeding further for error messsage in component
   * @param data server side response data
   * @returns based on server side result we are returning success/failure response
   */
  private validateResponse(data: any): any {
    return data.code === '01' ? data.response : null;
  }

  /**
   * Show server notification to users
   * @param notify For showing success/failure notifications
   * @param data Server side response data
   */
  private showNotify(notify: HttpNotify | null, data: any): void {

    this.notifyObj = data;
    const type = (this.notifyObj.status === 200 || this.notifyObj.code === '01') ? true : false;
    // Show Notification based on user's input
    if ((notify && notify.all) || (notify && notify.error && !type) || (notify && notify.success && type) || type === false ) {
      this.notifyService.Response = { type : type,  message : this.notifyObj.message };
    }
  }
}
