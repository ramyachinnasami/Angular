export interface Ishowschedule {
    interviewer: any;
    scheduleDate: any;
    scheduleFromTime: any;
    scheduleId: any;
    scheduleToTime: any;
    workflowId: any;
}
