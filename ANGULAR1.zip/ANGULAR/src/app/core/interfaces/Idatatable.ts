export interface Idatatable {
    datas: any;
    total_count: number;
}
