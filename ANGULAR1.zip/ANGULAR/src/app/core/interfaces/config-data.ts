import { ConfigModel } from './config';

export interface ConfigData {
	setModel(model: ConfigModel): void;
}
