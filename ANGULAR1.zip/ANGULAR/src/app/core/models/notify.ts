export class Notify {
    status: number;
    message: string;
    code: string;
}
