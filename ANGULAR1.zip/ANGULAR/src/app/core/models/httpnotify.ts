export class HttpNotify {
    all?: boolean;
    success?: boolean;
    error?: boolean;
}
